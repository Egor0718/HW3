package com.example.a20042023_2410_project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class TwoActivity extends AppCompatActivity {

    // создание полей
    private ImageButton imageButtonDigit;
    private ImageButton imageButtonGeometry;
    private ImageButton imageButtonFunction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two_activity);

        imageButtonDigit = findViewById(R.id.imageButtonDigit);
        imageButtonGeometry = findViewById(R.id.imageButtonGeometry);
        imageButtonFunction = findViewById(R.id.imageButtonFunction);

        imageButtonDigit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCenozoic = new Intent(getApplicationContext(), MonarchActivity.class); // переключение на новую активность кайнозойского периода
                intentCenozoic.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); // использование флага перемещения нужной активности на вершину стека
                startActivity(intentCenozoic);
            }
        });
        imageButtonGeometry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentMesozoic = new Intent(getApplicationContext(), DateActivity.class);
                intentMesozoic.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intentMesozoic);
            }
        });
        imageButtonFunction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentPaleozoic = new Intent(getApplicationContext(), SymbolsActivity.class);
                intentPaleozoic.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intentPaleozoic);
            }
        });
    }


}
package com.example.a20042023_2410_project1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SymbolsActivity extends AppCompatActivity {
    ListView symbolsList;
    private String[] arraySymbols = { "Гимн:Россия — священная наша держава,\n" +
            "Россия — любимая наша страна.\n" +
            "Могучая воля, великая слава —\n" +
            "Твое достоянье на все времена!\n" +
            "Славься, Отечество наше свободное,\n" +
            "Братских народов союз вековой,\n" +
            "Предками данная мудрость народная!\n" +
            "Славься, страна! Мы гордимся тобой!\n" +
            "От южных морей до полярного края\n" +
            "Раскинулись наши леса и поля.\n" +
            "Одна ты на свете! Одна ты такая —\n" +
            "Хранимая Богом родная земля!\n" +
            "Славься, Отечество наше свободное,\n" +
            "Братских народов союз вековой,\n" +
            "Предками данная мудрость народная!\n" +
            "Славься, страна! Мы гордимся тобой!\n" +
            "Широкий простор для мечты и для жизни\n" +
            "Грядущие нам открывают года.\n" +
            "Нам силу дает наша верность Отчизне.\n" +
            "Так было, так есть и так будет всегда!\n" +
            "Славься, Отечество наше свободное,\n" +
            "Братских народов союз вековой,\n" +
            "Предками данная мудрость народная!\n" +
            "Славься, страна! Мы гордимся тобой!"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symbol);
        symbolsList = findViewById(R.id.symbolsList);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arraySymbols);
        symbolsList.setAdapter(adapter);
    }
}
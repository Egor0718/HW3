package com.example.a20042023_2410_project1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class DateActivity extends AppCompatActivity {
    ListView dateList;
    private String[] arrayDate = {"1. 862 Начало княжения Рюрика","2. 988 Крещение Руси","3. 1147 Первое упоминание о Москве",
            "4. 1237–1480 Монголо-татарское иго","5. 1240 Невская битва","6. 1380 Куликовская битва","7. 1480 Стояние на реке Угре. Падение монгольского ига",
            "8. 1547 Венчание Ивана Грозного на царство","9. 1589 Учреждение патриаршества в России","10. 1598-1613 Смутное время","11. 1613 Избрание на царство Михаила Федоровича Романова",
            "12. 1654 Переяславская Рада ","13. 1670–1671 Восcтание Степана Разина","14. 1682–1725 Правление Петра I","15. 1700–1721 Северная война","16. 1703 Основание Санкт-Петербурга",
            "17. 1709 Полтавская битва","18. 1762–1796 Царствование Екатерины II","19. 1773–1775 Крестьянская война под предводительством Е. Пугачева","20. 1812–1813 Отечественная война",
            "21. 1812 Бородинское сражение","22. 1825 Восстание декабристов","23. 1861 Отмена крепостного права","24. 1905–1907 Первая русская революция","25. 1914 Вступление России в первую мировую войну",
            "26. 1917 Февральская революция. Свержение самодержавия","27. 1917 Октябрьская революция","28. 1918–1920 Гражданская война","29. 1922 Образование СССР",
            "30. 1941–1945 Великая отечественная война","31. 1991 Распад СССР",
           };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date);
        dateList = findViewById(R.id.dateList);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayDate);
        dateList.setAdapter(adapter);
    }
}

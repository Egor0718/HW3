package com.example.a20042023_2410_project1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MonarchActivity extends AppCompatActivity {
    ListView monarchList;
    private String[] arrayMonarch = {"Рюриковичи:", "862-879 гг. – Рюрик",  "879-912 гг. – Олег Вещий",
            "912-945 гг. – Игорь Рюрикович ", " 945-964 гг. – Ольга Святая ", "964-972 гг. – Святослав Игоревич ",
            "972-978 гг. – Ярополк Святославич", "978-1015 гг. – Владимир I Святославич(Креститель)","1015-1019 гг. - Святолполк I Владимирович",
            "1019-1054 гг. – Ярослав Мудрый","1054-1113 гг. - отсутствие значимых личностей","1113-1125 гг. – Владимир Мономах",
            "1125-1132 гг. – Мстислав Великий","1125-1157 гг. – Юрий Долгорукий","1176-1212 гг. – Всеволод Большое Гнездо","1252-1263 гг. – Александр Невский",
            "1325-1340 гг. – Иван I Данилович Калита","1353-1359 гг. – Иван II Красный","1359-1389 гг. – Дмитрий Донской",
            "1389-1425 гг. – Василий I","1425-1462 гг. – Василий II","1462-1505 гг. – Иван III","1505-1533 гг. – Василий III",
            "1533-1584 гг. – Иван IV Грозный", "1584-1598 гг. – Федор Иванович", "Династия пресеклась", "1598-1605 гг. – Борис Годунов",
            "1606-1610 гг. – Василий Шуйский", "Романовы: coming soon"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monarch);
        monarchList = findViewById(R.id.monarchList);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayMonarch);
        monarchList.setAdapter(adapter);
    }
}